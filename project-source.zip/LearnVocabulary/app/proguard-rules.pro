# Keep Room generated implementations and Gson payload models stable during R8 shrinking.
-keep class com.learnvocabulary.app.data.** { *; }
-keep class com.learnvocabulary.app.backup.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.reflect.TypeToken { *; }
