# Room schema snapshots

Room is configured with `exportSchema = true` and KSP `room.schemaLocation`. The first successful Gradle build generates the version-1 schema JSON in this directory. Commit generated schema snapshots alongside future database versions. For any later entity change, increment `AppDatabase.version` and add an explicit `Migration`; destructive fallback is intentionally disabled.
