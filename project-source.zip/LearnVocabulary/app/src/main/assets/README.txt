Place the licensed BengaliDictionary JSON array here as: words.json
Expected keys per record: i, w, b, e, z. See README.md for details.
The dictionary data is not bundled in this project archive because the user has not supplied the licensed data file.
