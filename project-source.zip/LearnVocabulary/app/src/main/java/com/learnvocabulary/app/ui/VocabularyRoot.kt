package com.learnvocabulary.app.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.learnvocabulary.app.AppContainer
import com.learnvocabulary.app.R
import com.learnvocabulary.app.backup.BackupManager
import com.learnvocabulary.app.data.ImportState
import com.learnvocabulary.app.platform.ReminderScheduler
import androidx.core.os.LocaleListCompat
import kotlinx.coroutines.launch

private data class Tab(val route: String, val icon: String, val label: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VocabularyRoot(container: AppContainer, activityContext: Context) {
    val requestedRoute = (activityContext as? android.app.Activity)?.intent?.getStringExtra("destination")
        ?.takeIf { it in setOf("learn", "quiz") } ?: "home"
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val settings by container.settings.settings.collectAsState(initial = com.learnvocabulary.app.data.AppSettings())
    val wordCount by container.vocabulary.wordCount().collectAsState(initial = 0)
    val importState by container.importer.state.collectAsState()
    val backup = remember { BackupManager(context.contentResolver, container.database, container.settings) }
    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var importSummary by remember { mutableStateOf<String?>(null) }
    var showResetConfirm by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching { backup.export(uri) }.onSuccess { importSummary = if (settings.language == "bn") "ব্যাকআপ সংরক্ষণ হয়েছে" else "Backup exported successfully" }
                .onFailure { importSummary = it.message ?: "Export failed" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { backup.inspect(uri) }.onSuccess { summary ->
                pendingImportUri = uri
                importSummary = if (settings.language == "bn") "${summary.learnedWords} শেখা শব্দ, ${summary.days} দিন, ${summary.customWords} নিজস্ব শব্দ। পুনরুদ্ধার করবে?" else "${summary.learnedWords} learned words, ${summary.days} days, ${summary.customWords} custom words. Restore this backup?"
            }.onFailure { importSummary = it.message ?: "Invalid backup" }
        }
    }

    LaunchedEffect(Unit) { container.importer.importIfNeeded() }

    val tabs = listOf(
        Tab("home", "⌂", R.string.home),
        Tab("learn", "▤", R.string.learn),
        Tab("score", "◔", R.string.score),
        Tab("words", "✎", R.string.words),
        Tab("quiz", "★", R.string.quiz),
        Tab("settings", "☷", R.string.settings)
    )
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "home"
    val showTabs = currentRoute in tabs.map { it.route }
    val titleRes = tabs.firstOrNull { it.route == currentRoute }?.label

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(titleRes ?: R.string.settings), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    if (!showTabs) IconButton(onClick = { nav.popBackStack() }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                }
            )
        },
        bottomBar = {
            if (showTabs) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { tab ->
                    val selected = currentRoute == tab.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = { nav.navigate(tab.route) { popUpTo(nav.graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true } },
                        icon = { Text(tab.icon, modifier = Modifier.semantics { contentDescription = context.getString(tab.label) }, style = MaterialTheme.typography.titleLarge) },
                        label = null
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (importState) {
                is ImportState.Loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                is ImportState.Failed -> {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(12.dp)) {
                            Text((importState as ImportState.Failed).message, color = MaterialTheme.colorScheme.onErrorContainer)
                            TextButton(onClick = { scope.launch { container.importer.importNow() } }) { Text(stringResource(R.string.retry_import)) }
                        }
                    }
                }
                else -> Unit
            }
            NavHost(navController = nav, startDestination = requestedRoute, modifier = Modifier.weight(1f)) {
                composable("home") { HomeScreen(container, wordCount, settings.dailyGoal, onNavigate = { nav.navigate(it) }) }
                composable("learn") { LearnScreen(container, settings) }
                composable("score") { ScoreScreen(container, settings.dailyGoal) }
                composable("words") { WordsScreen(container) }
                composable("quiz") { QuizScreen(container) }
                composable("settings") {
                    SettingsScreen(
                        container = container,
                        onHelp = { nav.navigate("help") },
                        onProfile = { nav.navigate("profile") },
                        onExport = { exportLauncher.launch("learn-vocabulary-backup-${java.time.LocalDate.now()}.json") },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/json", "*/*")) },
                        onReset = { showResetConfirm = true }
                    )
                }
                composable("help") { HelpScreen() }
                composable("profile") { ProfileScreen(container) }
            }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text(if (settings.language == "bn") "সব অগ্রগতি মুছবে?" else "Reset all progress?") },
            text = { Text(if (settings.language == "bn") "শেখার অগ্রগতি, নিজস্ব শব্দ, ইতিহাস, XP এবং সক্রিয় সেশন মুছে যাবে। ভাষা ও থিম থাকবে।" else "This deletes learning progress, custom words, daily history, XP and active sessions. Language and appearance settings stay." ) },
            confirmButton = { TextButton(onClick = { scope.launch { container.vocabulary.resetAllProgress(); showResetConfirm = false } }) { Text(if (settings.language == "bn") "মুছে ফেলো" else "Reset") } },
            dismissButton = { TextButton(onClick = { showResetConfirm = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    importSummary?.let { message ->
        val isConfirmation = pendingImportUri != null
        AlertDialog(
            onDismissRequest = { importSummary = null; pendingImportUri = null },
            title = { Text(if (isConfirmation) (if (settings.language == "bn") "ব্যাকআপ পুনরুদ্ধার" else "Restore backup") else (if (settings.language == "bn") "তথ্য" else "Notice")) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingImportUri
                    if (uri != null) scope.launch {
                        runCatching { backup.import(uri) }.onSuccess { importSummary = if (settings.language == "bn") "ব্যাকআপ পুনরুদ্ধার হয়েছে" else "Backup restored" }
                            .onFailure { importSummary = it.message ?: "Restore failed" }
                        pendingImportUri = null
                    } else importSummary = null
                }) { Text(if (isConfirmation) (if (settings.language == "bn") "পুনরুদ্ধার" else "Restore") else "OK") }
            },
            dismissButton = { if (isConfirmation) TextButton(onClick = { importSummary = null; pendingImportUri = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
