package com.learnvocabulary.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.lifecycleScope
import androidx.core.os.LocaleListCompat
import com.learnvocabulary.app.ui.LearnVocabularyTheme
import com.learnvocabulary.app.ui.VocabularyRoot
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val appContainer get() = (application as VocabApplication).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            val savedLanguage = appContainer.settings.settings.first().language
            val tags = if (savedLanguage == "bn") "bn" else "en"
            if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != tags) {
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tags))
            }
        }
        appContainer.speech.initialize()
        setContent {
            val settings by appContainer.settings.settings.collectAsState(initial = com.learnvocabulary.app.data.AppSettings())
            LearnVocabularyTheme(settings.theme) {
                VocabularyRoot(appContainer, this)
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) appContainer.speech.shutdown() else appContainer.speech.stop()
        super.onDestroy()
    }
}
