package com.learnvocabulary.app.data

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.InputStreamReader

sealed interface ImportState {
    data object Idle : ImportState
    data class Loading(val imported: Int) : ImportState
    data class Ready(val imported: Int) : ImportState
    data class Failed(val message: String) : ImportState
}

class DictionaryImporter(
    private val context: Context,
    private val database: AppDatabase,
    private val settings: SettingsRepository
) {
    private val mutableState = MutableStateFlow<ImportState>(ImportState.Idle)
    val state: StateFlow<ImportState> = mutableState

    suspend fun importIfNeeded() = withContext(Dispatchers.IO) {
        if (settings.settingsFirstValue().importComplete) {
            mutableState.value = ImportState.Ready(database.vocabularyDao().wordCount())
            return@withContext
        }
        importNow()
    }

    suspend fun importNow() = withContext(Dispatchers.IO) {
        val dao = database.vocabularyDao()
        var imported = 0
        try {
            context.assets.open("words.json").use { input ->
                database.withTransaction {
                    JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                        reader.isLenient = false
                        reader.beginArray()
                        val batch = ArrayList<WordEntity>(200)
                        while (reader.hasNext()) {
                            val parsed = readWord(reader)
                            if (parsed != null) batch += parsed
                            if (batch.size >= 200) {
                                dao.insertWords(batch.toList())
                                imported += batch.size
                                batch.clear()
                                mutableState.value = ImportState.Loading(imported)
                            }
                        }
                        reader.endArray()
                        if (batch.isNotEmpty()) {
                            dao.insertWords(batch)
                            imported += batch.size
                        }
                    }
                }
            }
            if (imported == 0 && dao.wordCount() == 0) {
                throw IllegalStateException("The dictionary contains no valid word records.")
            }
            settings.markImportComplete()
            mutableState.value = ImportState.Ready(dao.wordCount())
        } catch (e: java.io.FileNotFoundException) {
            mutableState.value = ImportState.Failed("words.json is missing from app/src/main/assets/.")
        } catch (e: Exception) {
            mutableState.value = ImportState.Failed(e.message ?: "Dictionary import failed. The database transaction was rolled back.")
        }
    }

    private fun readWord(reader: JsonReader): WordEntity? {
        var index: Int? = null
        var word = ""
        var meanings = emptyList<String>()
        var example = ""
        var frequency = 0.0
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "i" -> index = if (reader.peek() == JsonToken.NUMBER) reader.nextInt() else { reader.skipValue(); null }
                "w" -> word = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                "b" -> {
                    val values = mutableListOf<String>()
                    if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                        reader.beginArray()
                        while (reader.hasNext()) {
                            if (reader.peek() == JsonToken.STRING) values += reader.nextString()
                            else reader.skipValue()
                        }
                        reader.endArray()
                    } else reader.skipValue()
                    meanings = values
                }
                "e" -> example = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                "z" -> frequency = if (reader.peek() == JsonToken.NUMBER) reader.nextDouble() else { reader.skipValue(); 0.0 }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        val cleanWord = word.trim().lowercase()
        val validMeanings = meanings.map(String::trim).filter(String::isNotEmpty).take(3)
        if (index == null || index!! < 0 || !cleanWord.matches(Regex("[a-z]+")) || validMeanings.isEmpty() || !frequency.isFinite()) return null
        return WordEntity(
            id = index!!.toLong() + 1L,
            dictionaryIndex = index,
            word = cleanWord,
            meanings = validMeanings.joinToString("\u001f"),
            example = example.trim(),
            frequency = frequency
        )
    }
}

private suspend fun SettingsRepository.settingsFirstValue(): AppSettings = settings.first()
