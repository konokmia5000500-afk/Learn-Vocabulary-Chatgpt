package com.learnvocabulary.app.backup

import android.content.ContentResolver
import android.net.Uri
import androidx.room.withTransaction
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.learnvocabulary.app.data.AppDatabase
import com.learnvocabulary.app.data.DailyStatEntity
import com.learnvocabulary.app.data.SettingsRepository
import com.learnvocabulary.app.data.WordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.InputStreamReader
import java.io.OutputStreamWriter

private data class WordProgress(
    val dictionaryIndex: Int,
    val learned: Boolean,
    val learnAgain: Boolean,
    val learnLater: Boolean,
    val mistake: Boolean,
    val levelOverride: String?,
    val box: Int,
    val wrongCount: Int,
    val correctCount: Int,
    val lastQuizCorrect: Boolean?
)
private data class BackupPayload(
    val schemaVersion: Int,
    val appVersion: String,
    val exportedAt: String,
    val progress: List<WordProgress>,
    val customWords: List<WordEntity>,
    val dailyStats: List<DailyStatEntity>,
    val displayName: String,
    val dailyGoal: Int
)
data class BackupSummary(val learnedWords: Int, val days: Int, val customWords: Int)

class BackupManager(
    private val resolver: ContentResolver,
    private val database: AppDatabase,
    private val settings: SettingsRepository
) {
    private val gson = Gson()

    suspend fun export(uri: Uri) = withContext(Dispatchers.IO) {
        val dao = database.vocabularyDao()
        val all = dao.allWords()
        val prefs = settings.settings.first()
        val payload = BackupPayload(
            schemaVersion = 1,
            appVersion = "0.1.0",
            exportedAt = java.time.Instant.now().toString(),
            progress = all.filter { !it.isCustom && it.dictionaryIndex != null }.map {
                WordProgress(it.dictionaryIndex!!, it.learned, it.learnAgain, it.learnLater, it.mistake, it.levelOverride, it.box, it.wrongCount, it.correctCount, it.lastQuizCorrect)
            },
            customWords = all.filter { it.isCustom },
            dailyStats = dao.allDailyStats(),
            displayName = prefs.displayName,
            dailyGoal = prefs.dailyGoal
        )
        resolver.openOutputStream(uri)?.use { stream -> OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(gson.toJson(payload)) } }
            ?: throw IllegalStateException("Could not open the selected backup destination.")
    }

    suspend fun inspect(uri: Uri): BackupSummary = withContext(Dispatchers.IO) {
        val payload = readAndValidate(uri)
        BackupSummary(payload.progress.count { it.learned }, payload.dailyStats.size, payload.customWords.size)
    }

    suspend fun import(uri: Uri) = withContext(Dispatchers.IO) {
        val payload = readAndValidate(uri)
        val dao = database.vocabularyDao()
        val languageToKeep = settings.settings.first().language
        database.withTransaction {
            payload.progress.forEach { item ->
                val existing = dao.getByDictionaryIndex(item.dictionaryIndex) ?: return@forEach
                dao.updateWord(existing.copy(
                    learned = item.learned, learnAgain = item.learnAgain, learnLater = item.learnLater,
                    mistake = item.mistake, levelOverride = item.levelOverride,
                    box = item.box.coerceIn(0, 5), wrongCount = item.wrongCount.coerceAtLeast(0),
                    correctCount = item.correctCount.coerceAtLeast(0), lastQuizCorrect = item.lastQuizCorrect
                ))
            }
            payload.customWords.forEach { item ->
                val clean = item.word.trim().lowercase()
                if (clean.matches(Regex("[a-z]+")) && item.meanings.isNotBlank() && dao.findWord(clean) == null) {
                    dao.insertWord(item.copy(id = 0, dictionaryIndex = null, word = clean, isCustom = true))
                }
            }
            dao.clearDailyStats()
            payload.dailyStats.forEach { stat ->
                if (stat.date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) dao.putDailyStat(stat)
            }
            dao.clearLearningSession()
        }
        settings.update { it.copy(language = languageToKeep, displayName = payload.displayName.take(50), dailyGoal = payload.dailyGoal.coerceIn(1, 500)) }
    }

    private fun readAndValidate(uri: Uri): BackupPayload {
        val stream = resolver.openInputStream(uri) ?: throw IllegalArgumentException("Cannot read the selected file.")
        val payload = stream.use { InputStreamReader(it, Charsets.UTF_8).use { reader -> gson.fromJson(reader, BackupPayload::class.java) } }
            ?: throw IllegalArgumentException("The backup file is empty or invalid.")
        if (payload.schemaVersion != 1) throw IllegalArgumentException("Unsupported backup version.")
        if (payload.progress.size > 500_000 || payload.customWords.size > 20_000 || payload.dailyStats.size > 20_000) {
            throw IllegalArgumentException("The backup contains an unreasonable amount of data.")
        }
        if (payload.progress.any { it.dictionaryIndex < 0 || it.box !in 0..5 }) throw IllegalArgumentException("Invalid word progress data.")
        if (payload.customWords.any { !it.word.matches(Regex("[a-zA-Z]+")) || it.meanings.length > 2_000 }) throw IllegalArgumentException("Invalid custom word data.")
        return payload
    }
}
