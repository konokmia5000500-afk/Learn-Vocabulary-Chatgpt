package com.learnvocabulary.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VocabularyDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertWords(words: List<WordEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertWord(word: WordEntity): Long

    @Update
    suspend fun updateWord(word: WordEntity)

    @Query("SELECT * FROM words WHERE id = :id LIMIT 1")
    suspend fun getWord(id: Long): WordEntity?

    @Query("SELECT * FROM words WHERE word = :word COLLATE NOCASE LIMIT 1")
    suspend fun findWord(word: String): WordEntity?

    @Query("SELECT * FROM words WHERE dictionaryIndex = :index LIMIT 1")
    suspend fun getByDictionaryIndex(index: Int): WordEntity?

    @Query("SELECT * FROM words ORDER BY isCustom DESC, frequency DESC, word ASC LIMIT :limit OFFSET :offset")
    suspend fun getPage(limit: Int, offset: Int): List<WordEntity>

    @Query("""
        SELECT * FROM words
        WHERE (:filter = 'ALL'
            OR (:filter = 'LEARNED' AND learned = 1)
            OR (:filter = 'LEARN_AGAIN' AND learnAgain = 1)
            OR (:filter = 'LEARN_LATER' AND learnLater = 1)
            OR (:filter = 'MISTAKES' AND mistake = 1)
            OR (:filter IN ('EASY','MEDIUM','HARD','VERY_HARD') AND
                (CASE WHEN levelOverride IS NOT NULL THEN levelOverride
                    WHEN frequency >= 4.6 THEN 'EASY'
                    WHEN frequency >= 3.6 THEN 'MEDIUM'
                    WHEN frequency >= 3.0 THEN 'HARD' ELSE 'VERY_HARD' END) = :filter)
        )
        AND (:customOnly = 0 OR isCustom = 1)
        AND (
            (:bengali = 0 AND (:query = '' OR word LIKE :prefix COLLATE NOCASE OR word LIKE :contains COLLATE NOCASE))
            OR (:bengali = 1 AND (:query = '' OR meanings LIKE :contains))
        )
        ORDER BY CASE WHEN word LIKE :prefix COLLATE NOCASE THEN 0 ELSE 1 END,
                 learnAgain DESC, isCustom DESC, frequency DESC, word ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun search(
        query: String, prefix: String, contains: String,
        bengali: Int, filter: String, customOnly: Int,
        limit: Int, offset: Int
    ): List<WordEntity>

    @Query("SELECT * FROM words WHERE learned = 0 AND learnLater = 0 ORDER BY learnAgain DESC, isCustom DESC, frequency DESC LIMIT :limit")
    suspend fun nextLearningWords(limit: Int): List<WordEntity>

    @Query("SELECT * FROM words WHERE id IN (:ids)")
    suspend fun getWordsByIds(ids: List<Long>): List<WordEntity>

    @Query("SELECT * FROM words WHERE learnAgain = 1 AND learned = 0 ORDER BY wrongCount DESC LIMIT :limit")
    suspend fun reviewWords(limit: Int): List<WordEntity>

    @Query("SELECT * FROM words WHERE isCustom = 1 ORDER BY word")
    suspend fun customWords(): List<WordEntity>

    @Query("SELECT * FROM words")
    suspend fun allWords(): List<WordEntity>

    @Query("SELECT COUNT(*) FROM words")
    fun observeWordCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM words")
    suspend fun wordCount(): Int

    @Query("SELECT COUNT(*) FROM words WHERE learned = 1")
    suspend fun learnedCount(): Int

    @Query("SELECT COUNT(*) FROM words WHERE isCustom = 1")
    suspend fun customCount(): Int

    @Query("""
        SELECT CASE WHEN levelOverride IS NOT NULL THEN levelOverride
                    WHEN frequency >= 4.6 THEN 'EASY'
                    WHEN frequency >= 3.6 THEN 'MEDIUM'
                    WHEN frequency >= 3.0 THEN 'HARD' ELSE 'VERY_HARD' END AS level,
               COUNT(*) AS total,
               SUM(CASE WHEN learned = 1 THEN 1 ELSE 0 END) AS learned
        FROM words GROUP BY level
    """)
    suspend fun levelProgress(): List<LevelProgress>

    @Query("DELETE FROM words WHERE id = :id AND isCustom = 1")
    suspend fun deleteCustomWord(id: Long)

    @Query("UPDATE words SET learned = 1, learnAgain = 0, learnLater = 0 WHERE id = :id")
    suspend fun markLearned(id: Long)

    @Query("UPDATE words SET learnAgain = 1 WHERE id = :id AND learned = 0")
    suspend fun setLearnAgain(id: Long)

    @Query("UPDATE words SET learnLater = :enabled WHERE id = :id")
    suspend fun setLearnLater(id: Long, enabled: Boolean)

    @Query("UPDATE words SET mistake = :mistake, box = :box, wrongCount = :wrong, correctCount = :correct, lastQuizCorrect = :last WHERE id = :id")
    suspend fun updateQuizResult(id: Long, mistake: Boolean, box: Int, wrong: Int, correct: Int, last: Boolean)

    @Query("UPDATE words SET learned = 0, learnAgain = 0, learnLater = 0, mistake = 0, levelOverride = NULL, box = 0, wrongCount = 0, correctCount = 0, lastQuizCorrect = NULL WHERE isCustom = 0")
    suspend fun clearDictionaryProgress()

    @Query("DELETE FROM words WHERE isCustom = 1")
    suspend fun deleteAllCustomWords()

    @Query("DELETE FROM daily_stats")
    suspend fun clearDailyStats()

    @Query("SELECT * FROM daily_stats WHERE date = :date LIMIT 1")
    suspend fun getDailyStat(date: String): DailyStatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putDailyStat(stat: DailyStatEntity)

    @Query("SELECT * FROM daily_stats ORDER BY date")
    suspend fun allDailyStats(): List<DailyStatEntity>

    @Query("SELECT * FROM daily_stats ORDER BY date")
    fun observeDailyStats(): Flow<List<DailyStatEntity>>

    @Query("SELECT * FROM learning_session WHERE singletonId = 1 LIMIT 1")
    fun observeLearningSession(): Flow<LearningSessionEntity?>

    @Query("SELECT * FROM learning_session WHERE singletonId = 1 LIMIT 1")
    suspend fun getLearningSession(): LearningSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLearningSession(session: LearningSessionEntity)

    @Query("DELETE FROM learning_session")
    suspend fun clearLearningSession()
}
