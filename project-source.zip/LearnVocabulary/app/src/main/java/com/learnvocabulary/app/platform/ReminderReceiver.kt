package com.learnvocabulary.app.platform

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.learnvocabulary.app.MainActivity
import com.learnvocabulary.app.R
import com.learnvocabulary.app.VocabApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: "learn"
        val app = context.applicationContext as? VocabApplication
        if (app == null) { pending.finish(); return }
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val settings = app.container.settings.settings.first()
                val today = app.container.database.vocabularyDao().getDailyStat(LocalDate.now().toString())
                val shouldShow = if (kind == "quiz") {
                    settings.quizReminder && (today?.quizCorrect ?: 0) + (today?.quizWrong ?: 0) == 0
                } else {
                    settings.learningReminder && (today?.learned ?: 0) < settings.dailyGoal
                }
                if (shouldShow) showNotification(context, kind, settings.language == "bn")
                if (kind == "quiz" && settings.quizReminder) ReminderScheduler.schedule(context, "quiz", settings.quizTime)
                if (kind != "quiz" && settings.learningReminder) ReminderScheduler.schedule(context, "learn", settings.learningTime)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }

    private fun showNotification(context: Context, kind: String, bengali: Boolean) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel("learning_reminders", "Learning reminders", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val destination = if (kind == "quiz") "quiz" else "learn"
        val open = Intent(context, MainActivity::class.java).putExtra("destination", destination)
        val requestCode = if (kind == "quiz") 8202 else 8201
        val pending = PendingIntent.getActivity(context, requestCode, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = when {
            bengali && kind == "quiz" -> "কুইজের সময়"
            bengali -> "শেখার সময়"
            kind == "quiz" -> "Quiz time"
            else -> "Learning time"
        }
        val body = when {
            bengali && kind == "quiz" -> "আজকের শেখা শব্দগুলো দিয়ে কুইজ দাও।"
            bengali -> "আজকের শব্দ শেখার স্লাইডটি শেষ করো।"
            kind == "quiz" -> "Your vocabulary quiz is ready."
            else -> "Continue your daily vocabulary slide."
        }
        val notification = NotificationCompat.Builder(context, "learning_reminders")
            .setSmallIcon(R.drawable.ic_lv_logo)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(if (kind == "quiz") 92 else 91, notification) } catch (_: SecurityException) { }
    }
}

class BootTimeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext as? VocabApplication
        if (app == null) { pending.finish(); return }
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val settings = app.container.settings.settings.first()
                if (settings.learningReminder) ReminderScheduler.schedule(context, "learn", settings.learningTime)
                else ReminderScheduler.cancel(context, "learn")
                if (settings.quizReminder) ReminderScheduler.schedule(context, "quiz", settings.quizTime)
                else ReminderScheduler.cancel(context, "quiz")
            } catch (_: Exception) {
            } finally { pending.finish() }
        }
    }
}
