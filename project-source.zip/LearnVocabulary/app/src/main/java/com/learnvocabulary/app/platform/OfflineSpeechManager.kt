package com.learnvocabulary.app.platform

import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class OfflineSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {
    @Volatile private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var initError: Int? = null

    @Synchronized fun initialize() {
        if (engine == null) engine = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) initError = status
    }

    fun isEnglishOfflineReady(): Boolean = ready && offlineVoice("en") != null
    fun isBengaliOfflineReady(): Boolean = ready && offlineVoice("bn") != null

    fun speakWord(word: String, accent: String = "US", rate: Float = 1f, pitch: Float = 1f, speakBengali: String? = null) {
        val tts = engine ?: return
        if (!ready) return
        val english = offlineVoice("en", accent) ?: return
        tts.setVoice(english)
        tts.setSpeechRate(rate.coerceIn(0.5f, 2f))
        tts.setPitch(pitch.coerceIn(0.5f, 2f))
        tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "word-${word.hashCode()}")
        if (!speakBengali.isNullOrBlank()) {
            val bangla = offlineVoice("bn")
            if (bangla != null) {
                tts.playSilentUtterance(120, TextToSpeech.QUEUE_ADD, "pause")
                tts.setVoice(bangla)
                tts.speak(speakBengali, TextToSpeech.QUEUE_ADD, null, "meaning-${word.hashCode()}")
            }
        }
    }

    fun stop() { engine?.stop() }
    fun installVoiceDataIntent(): Intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
    fun shutdown() { engine?.stop(); engine?.shutdown(); engine = null; ready = false }

    private fun offlineVoice(language: String, accent: String = "US"): Voice? {
        val tts = engine ?: return null
        val candidates = tts.voices.orEmpty().filter {
            it.locale.language.equals(language, ignoreCase = true) && !it.isNetworkConnectionRequired
        }
        if (language == "en") {
            val preferred = if (accent == "UK") listOf("GB", "US") else listOf("US", "GB")
            for (country in preferred) candidates.firstOrNull { it.locale.country.equals(country, true) }?.let { return it }
        }
        return candidates.firstOrNull()
    }
}
