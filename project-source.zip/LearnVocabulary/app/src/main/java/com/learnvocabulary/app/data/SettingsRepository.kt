package com.learnvocabulary.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first

private val Context.settingsDataStore by preferencesDataStore(name = "learn_vocabulary_settings")

data class AppSettings(
    val language: String = "en",
    val theme: String = "LIGHT",
    val fontStyle: String = "CLASSIC",
    val fontSize: Float = 18f,
    val dailyGoal: Int = 10,
    val autoSpeak: Boolean = false,
    val speakBengali: Boolean = false,
    val englishAccent: String = "US",
    val speechRate: Float = 1f,
    val speechPitch: Float = 1f,
    val learningReminder: Boolean = false,
    val quizReminder: Boolean = false,
    val learningTime: String = "19:00",
    val quizTime: String = "20:00",
    val displayName: String = "Learner",
    val importComplete: Boolean = false
)

class SettingsRepository(private val context: Context) {
    private object K {
        val language = stringPreferencesKey("language")
        val theme = stringPreferencesKey("theme")
        val fontStyle = stringPreferencesKey("font_style")
        val fontSize = floatPreferencesKey("font_size")
        val dailyGoal = intPreferencesKey("daily_goal")
        val autoSpeak = booleanPreferencesKey("auto_speak")
        val speakBengali = booleanPreferencesKey("speak_bengali")
        val accent = stringPreferencesKey("english_accent")
        val speechRate = floatPreferencesKey("speech_rate")
        val speechPitch = floatPreferencesKey("speech_pitch")
        val learningReminder = booleanPreferencesKey("learning_reminder")
        val quizReminder = booleanPreferencesKey("quiz_reminder")
        val learningTime = stringPreferencesKey("learning_time")
        val quizTime = stringPreferencesKey("quiz_time")
        val displayName = stringPreferencesKey("display_name")
        val importComplete = booleanPreferencesKey("dictionary_import_complete")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { p ->
        AppSettings(
            language = p[K.language] ?: "en",
            theme = p[K.theme] ?: "LIGHT",
            fontStyle = p[K.fontStyle] ?: "CLASSIC",
            fontSize = p[K.fontSize] ?: 18f,
            dailyGoal = p[K.dailyGoal] ?: 10,
            autoSpeak = p[K.autoSpeak] ?: false,
            speakBengali = p[K.speakBengali] ?: false,
            englishAccent = p[K.accent] ?: "US",
            speechRate = p[K.speechRate] ?: 1f,
            speechPitch = p[K.speechPitch] ?: 1f,
            learningReminder = p[K.learningReminder] ?: false,
            quizReminder = p[K.quizReminder] ?: false,
            learningTime = p[K.learningTime] ?: "19:00",
            quizTime = p[K.quizTime] ?: "20:00",
            displayName = p[K.displayName] ?: "Learner",
            importComplete = p[K.importComplete] ?: false
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        val current = settingsFirst()
        val next = transform(current)
        context.settingsDataStore.edit { p ->
            p[K.language] = next.language
            p[K.theme] = next.theme
            p[K.fontStyle] = next.fontStyle
            p[K.fontSize] = next.fontSize.coerceIn(14f, 24f)
            p[K.dailyGoal] = next.dailyGoal.coerceIn(1, 500)
            p[K.autoSpeak] = next.autoSpeak
            p[K.speakBengali] = next.speakBengali
            p[K.accent] = next.englishAccent
            p[K.speechRate] = next.speechRate.coerceIn(0.5f, 2f)
            p[K.speechPitch] = next.speechPitch.coerceIn(0.5f, 2f)
            p[K.learningReminder] = next.learningReminder
            p[K.quizReminder] = next.quizReminder
            p[K.learningTime] = next.learningTime
            p[K.quizTime] = next.quizTime
            p[K.displayName] = next.displayName.take(50)
            p[K.importComplete] = next.importComplete
        }
    }

    suspend fun markImportComplete() = update { it.copy(importComplete = true) }
    suspend fun markImportIncomplete() = update { it.copy(importComplete = false) }
    private suspend fun settingsFirst(): AppSettings = settings.first()
}
