package com.learnvocabulary.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color

private val Parchment = lightColorScheme(
    primary = Color(0xFF8A2B2B), onPrimary = Color.White,
    secondary = Color(0xFFB8892B), onSecondary = Color(0xFF21170C),
    background = Color(0xFFF7F0E1), onBackground = Color(0xFF2C2118),
    surface = Color(0xFFFFFAF0), onSurface = Color(0xFF2C2118),
    surfaceVariant = Color(0xFFEFE4CF), onSurfaceVariant = Color(0xFF7A6A55),
    outline = Color(0xFFE0D2B4), error = Color(0xFFB3362F)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFE0A458), onPrimary = Color(0xFF24170C),
    secondary = Color(0xFFCCAA68), background = Color(0xFF14110D), onBackground = Color(0xFFF0E6D2),
    surface = Color(0xFF221C15), onSurface = Color(0xFFF0E6D2), surfaceVariant = Color(0xFF34291E),
    onSurfaceVariant = Color(0xFFC5B79E), outline = Color(0xFF584735)
)
private val Sepia = lightColorScheme(
    primary = Color(0xFF7A3B14), secondary = Color(0xFFAE7935), background = Color(0xFFE8D8B4),
    surface = Color(0xFFF4E7C9), onSurface = Color(0xFF322114), onBackground = Color(0xFF322114)
)
private val Forest = darkColorScheme(
    primary = Color(0xFFE3C26A), secondary = Color(0xFF9BBE9A), background = Color(0xFF17261F),
    surface = Color(0xFF223A2E), onSurface = Color(0xFFEAF1E4), onBackground = Color(0xFFEAF1E4)
)

@Composable
fun LearnVocabularyTheme(theme: String, content: @Composable () -> Unit) {
    val colors = when (theme) {
        "DARK" -> Dark
        "SEPIA" -> Sepia
        "FOREST" -> Forest
        "SYSTEM" -> if (isSystemInDarkTheme()) Dark else Parchment
        else -> Parchment
    }
    MaterialTheme(colorScheme = colors, content = content)
}
