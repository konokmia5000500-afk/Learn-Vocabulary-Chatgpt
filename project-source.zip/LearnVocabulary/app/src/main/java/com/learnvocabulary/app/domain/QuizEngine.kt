package com.learnvocabulary.app.domain

import com.learnvocabulary.app.data.WordEntity
import kotlin.random.Random

object QuizEngine {
    fun weight(word: WordEntity): Double {
        var result = 1.0
        if (word.learnAgain) result += 3.0
        if (word.level() == "HARD" || word.level() == "VERY_HARD") result += 2.0
        if (word.levelOverride == "EASY") result -= 0.5
        result += (3 - word.box).coerceAtLeast(0)
        result += word.wrongCount.coerceAtMost(4)
        if (word.mistake) result += 3.0
        return result.coerceAtLeast(0.1)
    }

    fun weightedSample(words: List<WordEntity>, count: Int, random: Random = Random.Default): List<WordEntity> {
        val pool = words.distinctBy { it.id }.toMutableList()
        val output = mutableListOf<WordEntity>()
        repeat(count.coerceAtMost(pool.size)) {
            val total = pool.sumOf(::weight)
            var pick = random.nextDouble() * total
            var selected = pool.last()
            for (item in pool) {
                pick -= weight(item)
                if (pick <= 0.0) { selected = item; break }
            }
            output += selected
            pool.remove(selected)
        }
        return output
    }

    fun applyCorrectBox(box: Int): Int = (box + 1).coerceAtMost(5)
    fun applyWrongBox(): Int = 0
}
