package com.learnvocabulary.app.ui

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import com.learnvocabulary.app.AppContainer
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.AppSettings
import com.learnvocabulary.app.data.DailyStatEntity
import com.learnvocabulary.app.data.LearningSessionEntity
import com.learnvocabulary.app.data.WordEntity
import com.learnvocabulary.app.domain.QuizEngine
import com.learnvocabulary.app.platform.ReminderScheduler
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
private fun LVCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (title != null) Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
fun HomeScreen(container: AppContainer, wordCount: Int, dailyGoal: Int, onNavigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var learnedToday by remember { mutableIntStateOf(0) }
    val stats by container.vocabulary.dailyStats().collectAsState(initial = emptyList())
    LaunchedEffect(stats) { learnedToday = stats.firstOrNull { it.date == LocalDate.now().toString() }?.learned ?: 0 }
    PageColumn {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                Text("LV", color = MaterialTheme.colorScheme.onPrimary, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
            Column {
                Text("Learn", style = MaterialTheme.typography.headlineMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
                Text("Vocabulary", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary)
            }
        }
        LVCard {
            Text(stringResource(R.string.welcome), style = MaterialTheme.typography.bodyLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric(stringResource(R.string.dictionary_words), wordCount.toString())
                Metric(stringResource(R.string.words_per_slide), dailyGoal.toString())
                Metric(stringResource(R.string.fully_offline), "✓")
            }
        }
        LVCard(title = stringResource(R.string.todays_goal)) {
            Text("$learnedToday / $dailyGoal", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            LinearProgressIndicator(progress = { (learnedToday.toFloat() / dailyGoal.coerceAtLeast(1)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { onNavigate("learn") }, modifier = Modifier.fillMaxWidth()) { Text(if (learnedToday >= dailyGoal) stringResource(R.string.daily_goal_complete) else stringResource(R.string.start_learning)) }
        }
        Text(if (LocalDate.now().dayOfWeek.value > 0) "Explore" else "Explore", style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Serif)
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(250.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
            val features = listOf("Learn" to "learn", "Quiz" to "quiz", "Score" to "score", "Words" to "words", "Settings" to "settings")
            items(features) { item ->
                Card(Modifier.fillMaxWidth().clickable { onNavigate(item.second) }, shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(when (item.second) { "learn" -> "Study new words"; "quiz" -> "Test your memory"; "score" -> "Review your progress"; "words" -> "Search and manage"; else -> "Personalize the app" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        LVCard(title = "My lists") {
            val filters = listOf("EASY", "MEDIUM", "HARD", "VERY_HARD", "LEARN_AGAIN", "LEARN_LATER", "MISTAKES")
            filters.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { filter ->
                        AssistChip(onClick = { onNavigate("words") }, label = { Text(filter.replace('_', ' ').lowercase().replaceFirstChar(Char::uppercase)) })
                    }
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(Modifier.widthIn(max = 105.dp)) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LearnScreen(container: AppContainer, settings: AppSettings) {
    val scope = rememberCoroutineScope()
    val session by container.vocabulary.learningSession().collectAsState(initial = null)
    var currentWord by remember { mutableStateOf<WordEntity?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var goalReachedShown by remember { mutableStateOf(false) }
    LaunchedEffect(session?.queueIds, session?.position, session?.finished) {
        val active = session
        currentWord = if (active == null || active.finished) null else container.vocabulary.currentSlideWord(active)
        loaded = true
    }
    LaunchedEffect(currentWord?.id, settings.autoSpeak) {
        val word = currentWord
        if (word != null && settings.autoSpeak) {
            container.speech.speakWord(word.word, settings.englishAccent, settings.speechRate, settings.speechPitch, if (settings.speakBengali) word.meaningList().firstOrNull() else null)
        }
    }
    PageColumn {
        LVCard(title = stringResource(R.string.todays_goal)) {
            val stats by container.vocabulary.dailyStats().collectAsState(initial = emptyList())
            val today = stats.firstOrNull { it.date == LocalDate.now().toString() }?.learned ?: 0
            Text("$today / ${settings.dailyGoal}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            LinearProgressIndicator(progress = { (today.toFloat() / settings.dailyGoal.coerceAtLeast(1)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
        if (!loaded) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        else if (currentWord != null && session != null) {
            val active = session!!
            Text("${active.done} / ${active.initialTotal}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = { if (active.initialTotal == 0) 1f else (active.done.toFloat() / active.initialTotal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            AnimatedContent(
                targetState = currentWord,
                transitionSpec = { (fadeIn() + slideInHorizontally { it / 10 }) togetherWith (fadeOut() + slideOutHorizontally { -it / 10 }) },
                label = "learning-word"
            ) { word ->
                if (word != null) WordLearningCard(word, container, settings,
                    onLearned = { scope.launch { container.vocabulary.markCurrentLearned(active) } },
                    onAgain = { scope.launch { container.vocabulary.deferCurrent(active) } },
                    onLater = { scope.launch { container.vocabulary.skipForLater(active) } }
                )
            }
        } else {
            val completed = session?.finished == true
            LVCard(title = if (completed) stringResource(R.string.slide_complete) else "Learn by type") {
                Text(if (completed) "You finished this slide. Start another slide when you are ready." else "Words are chosen in this order: review, your words, then the dictionary.")
                Button(onClick = { scope.launch { container.vocabulary.startSlide(settings.dailyGoal) } }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (completed) "New slide" else "${stringResource(R.string.start_slide)} (${settings.dailyGoal} words)")
                }
            }
        }
    }
}

@Composable
private fun WordLearningCard(
    word: WordEntity,
    container: AppContainer,
    settings: AppSettings,
    onLearned: () -> Unit,
    onAgain: () -> Unit,
    onLater: () -> Unit
) {
    var selectedLevel by remember(word.id, word.levelOverride) { mutableStateOf(word.levelOverride) }
    LVCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            AssistChip(onClick = {}, label = { Text(word.level().replace('_', ' ')) })
            Row {
                if (word.learnAgain) AssistChip(onClick = {}, label = { Text("Review") })
                Text("🔊", modifier = Modifier.clip(CircleShape).clickable { container.speech.speakWord(word.word, settings.englishAccent, settings.speechRate, settings.speechPitch, if (settings.speakBengali) word.meaningList().firstOrNull() else null) }.semantics { contentDescription = "Speak ${word.word}" }.padding(8.dp))
            }
        }
        Text(word.word, style = MaterialTheme.typography.displaySmall, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        word.meaningList().forEachIndexed { index, meaning ->
            Text(meaning, style = if (index == 0) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium, fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        if (word.example.isNotBlank()) Text(word.example, style = MaterialTheme.typography.bodyLarge, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Divider(color = MaterialTheme.colorScheme.outline)
        Text("Set difficulty", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("EASY", "MEDIUM", "HARD", "VERY_HARD").forEach { level ->
                FilterChip(selected = selectedLevel == level, onClick = {
                    selectedLevel = if (selectedLevel == level) null else level
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch { container.vocabulary.setLevel(word.id, selectedLevel) }
                }, label = { Text(level.take(1) + level.drop(1).lowercase().replace('_', ' '), fontSize = 10.sp) })
            }
        }
        Button(onClick = onLearned, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.learned) + "  +5 XP") }
        OutlinedButton(onClick = onAgain, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.learn_again)) }
        TextButton(onClick = onLater, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.learn_later)) }
    }
}

@Composable
fun WordsScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    var query by remember { mutableStateOf("") }
    var bengali by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("ALL") }
    var customOnly by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<WordEntity>>(emptyList()) }
    var offset by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<WordEntity?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val pageSize = 40

    fun reload(reset: Boolean = true) {
        scope.launch {
            if (reset) { offset = 0; results = emptyList() }
            val page = container.vocabulary.search(query.trim(), bengali, filter, customOnly, pageSize, if (reset) 0 else offset)
            results = if (reset) page else results + page
            offset = results.size
        }
    }
    LaunchedEffect(query, bengali, filter, customOnly) { reload(true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.search_words)) }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            FilterChip(selected = !bengali, onClick = { bengali = false }, label = { Text(stringResource(R.string.english)) })
            FilterChip(selected = bengali, onClick = { bengali = true }, label = { Text(stringResource(R.string.bengali)) })
            FilterChip(selected = customOnly, onClick = { customOnly = !customOnly }, label = { Text(stringResource(R.string.my_words)) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { expanded = true }) { Text(filter.replace('_', ' ')) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    listOf("ALL", "EASY", "MEDIUM", "HARD", "VERY_HARD", "LEARN_AGAIN", "LEARN_LATER", "MISTAKES", "LEARNED").forEach { option ->
                        DropdownMenuItem(text = { Text(option.replace('_', ' ')) }, onClick = { filter = option; expanded = false })
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("+", modifier = Modifier.clickable { showAdd = true }.semantics { contentDescription = "Add word" }.padding(10.dp), style = MaterialTheme.typography.headlineSmall)
        }
        if (results.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(stringResource(R.string.no_words)) }
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(results, key = { it.id }) { word ->
                Card(Modifier.fillMaxWidth().clickable { detail = word }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(word.word, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(word.meaningList().take(2).joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("🔊", modifier = Modifier.clickable { container.speech.speakWord(word.word, settings.englishAccent, settings.speechRate, settings.speechPitch) }.semantics { contentDescription = "Speak ${word.word}" }.padding(8.dp))
                        if (word.learned) Text("✓", color = Color(0xFF2F7D4F), fontWeight = FontWeight.Bold)
                    }
                }
            }
            item { TextButton(onClick = { reload(false) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.show_more)) } }
        }
    }
    if (showAdd) AddWordDialog(onDismiss = { showAdd = false }, onSave = { word, meanings, example ->
        scope.launch { val ok = container.vocabulary.addCustomWord(word, meanings, example); message = if (ok) "Saved" else "Word is invalid or already exists"; showAdd = false; reload() }
    })
    detail?.let { word ->
        AlertDialog(onDismissRequest = { detail = null }, title = { Text(word.word, fontFamily = FontFamily.Serif) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                word.meaningList().forEach { Text(it) }
                if (word.example.isNotBlank()) Text(word.example, fontStyle = FontStyle.Italic)
                Text("Difficulty: ${word.level()}")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Learn later", modifier = Modifier.weight(1f))
                    Switch(checked = word.learnLater, onCheckedChange = { enabled -> scope.launch { container.vocabulary.setLearnLater(word.id, enabled); detail = word.copy(learnLater = enabled); reload() } })
                }
            }
        }, confirmButton = { TextButton(onClick = { detail = null }) { Text(stringResource(R.string.cancel)) } })
    }
    message?.let { AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }, text = { Text(it) }) }
}

@Composable
private fun AddWordDialog(onDismiss: () -> Unit, onSave: (String, List<String>, String) -> Unit) {
    var word by remember { mutableStateOf("") }
    var meanings by remember { mutableStateOf("") }
    var example by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_word)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(word, { word = it }, label = { Text("English word") }, singleLine = true)
                OutlinedTextField(meanings, { meanings = it }, label = { Text(stringResource(R.string.meaning)) }, minLines = 2)
                OutlinedTextField(example, { example = it }, label = { Text(stringResource(R.string.example)) })
            }
        },
        confirmButton = { TextButton(onClick = { onSave(word, meanings.split(','), example) }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun QuizScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf("ALL") }
    var questionCount by remember { mutableIntStateOf(10) }
    var pool by remember { mutableStateOf<List<WordEntity>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var options by remember { mutableStateOf<List<WordEntity>>(emptyList()) }
    var hearts by remember { mutableIntStateOf(5) }
    var correct by remember { mutableIntStateOf(0) }
    var wrong by remember { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf<String?>(null) }
    var started by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }
    var xp by remember { mutableIntStateOf(0) }

    fun prepareOptions() {
        val current = pool.getOrNull(index) ?: return
        val distractors = pool.filter { it.id != current.id }.shuffled().take(3)
        options = (distractors + current).shuffled()
    }
    fun start() {
        scope.launch {
            val words = if (source == "CUSTOM") container.vocabulary.customWords() else container.vocabulary.allWords()
            pool = QuizEngine.weightedSample(words.filter { it.learned || it.isCustom }.ifEmpty { words }, questionCount)
            index = 0; hearts = 5; correct = 0; wrong = 0; xp = 0; answer = null
            started = pool.isNotEmpty(); finished = pool.isEmpty()
            prepareOptions()
        }
    }
    fun submit(option: WordEntity) {
        val current = pool.getOrNull(index) ?: return
        if (answer != null) return
        val isCorrect = option.id == current.id
        answer = if (isCorrect) "CORRECT" else "WRONG"
        if (isCorrect) { correct++; xp += 10 + (correct.coerceAtMost(5)); scope.launch { container.vocabulary.recordQuiz(current.id, true) } }
        else { wrong++; hearts--; scope.launch { container.vocabulary.recordQuiz(current.id, false) } }
    }
    PageColumn {
        if (!started && !finished) {
            LVCard(title = "Quiz setup") {
                Text("Source")
                Row { FilterChip(source == "ALL", { source = "ALL" }, label = { Text(stringResource(R.string.all_words)) }); Spacer(Modifier.width(8.dp)); FilterChip(source == "CUSTOM", { source = "CUSTOM" }, label = { Text(stringResource(R.string.my_words)) }) }
                Text("Question count")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(10, 15, 20).forEach { FilterChip(questionCount == it, { questionCount = it }, label = { Text(it.toString()) }) } }
                Text("Five hearts · Correct +10 XP · Spaced repetition")
                Button(onClick = { start() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.quiz_start)) }
            }
        } else if (finished || hearts <= 0 || index >= pool.size) {
            LVCard(title = if (hearts <= 0) "Out of hearts" else "Quiz complete") {
                Text("XP: $xp", style = MaterialTheme.typography.headlineMedium)
                Text("Correct: $correct · Wrong: $wrong · Accuracy: ${if (correct + wrong == 0) 0 else correct * 100 / (correct + wrong)}%")
                Button(onClick = { finished = false; started = false }, modifier = Modifier.fillMaxWidth()) { Text("Quiz setup") }
            }
        } else {
            val current = pool[index]
            Text("Question ${index + 1} / ${pool.size}    Hearts: ${"♥".repeat(hearts.coerceAtLeast(0))}", style = MaterialTheme.typography.titleMedium)
            LVCard {
                Text(current.word, style = MaterialTheme.typography.displaySmall, fontFamily = FontFamily.Serif, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("Choose the Bengali meaning", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            options.forEach { option ->
                OutlinedButton(onClick = { submit(option) }, modifier = Modifier.fillMaxWidth(), enabled = answer == null) { Text(option.meaningList().firstOrNull().orEmpty()) }
            }
            answer?.let { result ->
                LVCard(title = if (result == "CORRECT") "Correct!" else "Not quite") {
                    Text("Answer: ${current.word} — ${current.meaningList().firstOrNull().orEmpty()}")
                    Button(onClick = {
                        answer = null; index++
                        if (index >= pool.size || hearts <= 0) finished = true else prepareOptions()
                    }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.next)) }
                }
            }
        }
    }
}

@Composable
fun ScoreScreen(container: AppContainer, dailyGoal: Int) {
    val stats by container.vocabulary.dailyStats().collectAsState(initial = emptyList())
    val counts by produceState(initial = 0 to 0, container) { value = container.vocabulary.counts() }
    val learned = counts.second
    val total = counts.first
    val percent = if (total == 0) 0 else learned * 100 / total
    val levelCounts by produceState(initialValue = emptyList<com.learnvocabulary.app.data.LevelProgress>(), container) {
        value = container.vocabulary.levelProgress()
    }
    PageColumn {
        LVCard(title = "Overall progress") {
            Text("$learned / $total words learned", style = MaterialTheme.typography.titleLarge)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(218.dp)) {
                    val all = listOf("OVERALL", "EASY", "MEDIUM", "HARD", "VERY_HARD")
                    val colors = listOf(Color(0xFF8A2B2B), Color(0xFF2F7D4F), Color(0xFFB8892B), Color(0xFF8A2B2B), Color(0xFFB3362F))
                    all.forEachIndexed { index, key ->
                        val item = if (key == "OVERALL") (learned to total) else {
                            val level = levelCounts.firstOrNull { it.level == key }
                            (level?.learned ?: 0) to (level?.total ?: 0)
                        }
                        val inset = 8f + index * 20f
                        val diameter = size.minDimension - inset * 2f
                        val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                        val ringSize = Size(diameter, diameter)
                        val stroke = Stroke(width = 10f, cap = StrokeCap.Round)
                        drawArc(colors[index].copy(alpha = 0.18f), -90f, 360f, false, topLeft, ringSize, style = stroke)
                        val sweep = if (item.second <= 0) 0f else 360f * item.first.toFloat() / item.second
                        drawArc(colors[index], -90f, sweep.coerceIn(0f, 360f), false, topLeft, ringSize, style = stroke)
                    }
                }
            }
            listOf("Overall", "Easy", "Medium", "Hard", "Very hard").forEachIndexed { index, label ->
                val key = label.uppercase().replace(' ', '_')
                val counts = if (index == 0) learned to total else {
                    val level = levelCounts.firstOrNull { it.level == key }
                    (level?.learned ?: 0) to (level?.total ?: 0)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(listOf(Color(0xFF8A2B2B), Color(0xFF2F7D4F), Color(0xFFB8892B), Color(0xFF8A2B2B), Color(0xFFB3362F))[index]))
                    Text("$label  ${counts.first}/${counts.second}  (${if (counts.second == 0) 0 else counts.first * 100 / counts.second}%)", modifier = Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("$percent% complete · ${((total - learned).coerceAtLeast(0) + dailyGoal.coerceAtLeast(1) - 1) / dailyGoal.coerceAtLeast(1)} estimated days at $dailyGoal words/day")
        }
        LVCard(title = "Learning activity") {
            Text("Last 7 days", style = MaterialTheme.typography.labelLarge)
            val recent = stats.takeLast(7)
            Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                recent.forEach { stat ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Box(Modifier.width(22.dp).height((stat.learned * 6).coerceIn(4, 90).dp).clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)).background(MaterialTheme.colorScheme.primary))
                        Text(stat.date.takeLast(2), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        LVCard(title = "Quiz summary") {
            val correct = stats.sumOf { it.quizCorrect }
            val wrong = stats.sumOf { it.quizWrong }
            Text("Correct: $correct    Wrong: $wrong")
            Text("Accuracy: ${if (correct + wrong == 0) 0 else correct * 100 / (correct + wrong)}%")
        }
        LVCard(title = "Learning days") {
            val activeDays = stats.count { it.learned > 0 || it.quizCorrect + it.quizWrong > 0 }
            Text("$activeDays active days")
            stats.takeLast(30).forEach { Text("${it.date}   ${it.learned} learned   ${it.quizCorrect}✓ / ${it.quizWrong}✕") }
        }
    }
}

@Composable
fun SettingsScreen(
    container: AppContainer,
    onHelp: () -> Unit,
    onProfile: () -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    val context = androidx.compose.ui.platform.LocalContext.current
    PageColumn {
        LVCard(title = "Account and help") {
            OutlinedButton(onClick = onProfile, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.profile)) }
            OutlinedButton(onClick = onHelp, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.help)) }
            Text("About · Learn Vocabulary 0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LVCard(title = stringResource(R.string.appearance)) {
            Text(stringResource(R.string.language))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(settings.language == "en", { scope.launch { container.settings.update { it.copy(language = "en") }; AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en")) } }, label = { Text("English") })
                FilterChip(settings.language == "bn", { scope.launch { container.settings.update { it.copy(language = "bn") }; AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("bn")) } }, label = { Text("বাংলা") })
            }
            Text(stringResource(R.string.theme))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("SYSTEM", "LIGHT", "DARK", "SEPIA", "FOREST").forEach { theme -> FilterChip(settings.theme == theme, { scope.launch { container.settings.update { it.copy(theme = theme) } } }, label = { Text(theme.lowercase()) }) } }
            Text("Font style")
            Row { listOf("CLASSIC", "SERIF", "SANS").forEach { style -> FilterChip(settings.fontStyle == style, { scope.launch { container.settings.update { it.copy(fontStyle = style) } } }, label = { Text(style.lowercase()) }) } }
            Text("${stringResource(R.string.font_size)}: ${settings.fontSize.toInt()}sp")
            Slider(value = settings.fontSize, onValueChange = { v -> scope.launch { container.settings.update { it.copy(fontSize = v) } } }, valueRange = 14f..24f)
        }
        LVCard(title = stringResource(R.string.daily_words)) {
            Text("This sets both the daily target and words per learning slide.")
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf(5, 10, 15, 20, 30, 50).forEach { n -> FilterChip(settings.dailyGoal == n, { scope.launch { container.settings.update { it.copy(dailyGoal = n) } } }, label = { Text(n.toString()) }) } }
            var custom by remember { mutableStateOf("") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(custom, { custom = it.filter(Char::isDigit).take(3) }, label = { Text("Custom 1–500") }, modifier = Modifier.weight(1f), singleLine = true)
                TextButton(onClick = { custom.toIntOrNull()?.takeIf { it in 1..500 }?.let { n -> scope.launch { container.settings.update { it.copy(dailyGoal = n) } } } }) { Text("Set") }
            }
        }
        LVCard(title = stringResource(R.string.voice)) {
            SettingSwitch(stringResource(R.string.auto_speak), settings.autoSpeak) { scope.launch { container.settings.update { it.copy(autoSpeak = it.autoSpeak.not()) } } }
            SettingSwitch(stringResource(R.string.speak_meaning), settings.speakBengali, enabled = container.speech.isBengaliOfflineReady()) { scope.launch { container.settings.update { it.copy(speakBengali = it.speakBengali.not()) } } }
            Text("English offline voice: ${if (container.speech.isEnglishOfflineReady()) "ready" else "not installed"}")
            Text("Bengali offline voice: ${if (container.speech.isBengaliOfflineReady()) "available" else "not available"}")
            Row { FilterChip(settings.englishAccent == "US", { scope.launch { container.settings.update { it.copy(englishAccent = "US") } } }, label = { Text("US") }); Spacer(Modifier.width(6.dp)); FilterChip(settings.englishAccent == "UK", { scope.launch { container.settings.update { it.copy(englishAccent = "UK") } } }, label = { Text("UK") }) }
            Text("Speech rate")
            Slider(value = settings.speechRate, onValueChange = { v -> scope.launch { container.settings.update { it.copy(speechRate = v) } } }, valueRange = 0.5f..2f)
            Text("Pitch")
            Slider(value = settings.speechPitch, onValueChange = { v -> scope.launch { container.settings.update { it.copy(speechPitch = v) } } }, valueRange = 0.5f..2f)
            OutlinedButton(onClick = { container.speech.speakWord("Vocabulary", settings.englishAccent, settings.speechRate, settings.speechPitch) }) { Text("Test English voice") }
            if (!container.speech.isEnglishOfflineReady()) TextButton(onClick = { context.startActivity(container.speech.installVoiceDataIntent()) }) { Text("Install offline voice data") }
        }
        LVCard(title = stringResource(R.string.reminders)) {
            SettingSwitch(stringResource(R.string.learning_reminder), settings.learningReminder) { enabled ->
                if (enabled) requestReminderPermissions(context)
                scope.launch { container.settings.update { it.copy(learningReminder = enabled) } }
                if (enabled) ReminderScheduler.schedule(context, "learn", settings.learningTime) else ReminderScheduler.cancel(context, "learn")
            }
            TextButton(onClick = {
                val parts = settings.learningTime.split(":")
                TimePickerDialog(context, { _, hour, minute ->
                    val value = "%02d:%02d".format(hour, minute)
                    scope.launch { container.settings.update { it.copy(learningTime = value) } }
                    if (settings.learningReminder) ReminderScheduler.schedule(context, "learn", value)
                }, parts.getOrNull(0)?.toIntOrNull() ?: 19, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
            }) { Text("Learning time: ${settings.learningTime}") }
            SettingSwitch(stringResource(R.string.quiz_reminder), settings.quizReminder) { enabled ->
                if (enabled) requestReminderPermissions(context)
                scope.launch { container.settings.update { it.copy(quizReminder = enabled) } }
                if (enabled) ReminderScheduler.schedule(context, "quiz", settings.quizTime) else ReminderScheduler.cancel(context, "quiz")
            }
            TextButton(onClick = {
                val parts = settings.quizTime.split(":")
                TimePickerDialog(context, { _, hour, minute ->
                    val value = "%02d:%02d".format(hour, minute)
                    scope.launch { container.settings.update { it.copy(quizTime = value) } }
                    if (settings.quizReminder) ReminderScheduler.schedule(context, "quiz", value)
                }, parts.getOrNull(0)?.toIntOrNull() ?: 20, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
            }) { Text("Quiz time: ${settings.quizTime}") }
            val notificationsAllowed = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            val exactAlarmsAllowed = Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()
            val powerManager = context.getSystemService(PowerManager::class.java)
            val batteryUnrestricted = powerManager.isIgnoringBatteryOptimizations(context.packageName)
            Text("Notifications: ${if (notificationsAllowed) "allowed" else "not allowed"}")
            Text("Exact alarms: ${if (exactAlarmsAllowed) "allowed" else "permission needed"}")
            Text("Battery optimization: ${if (batteryUnrestricted) "not restricting" else "may restrict reminders"}")
            OutlinedButton(onClick = {
                val intent = when {
                    !notificationsAllowed -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    !exactAlarmsAllowed -> Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                    else -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                }
                context.startActivity(intent)
            }, modifier = Modifier.fillMaxWidth()) { Text("Open Android reminder permissions") }
            Text("Battery optimization may delay reminders. Android notification permission is required on Android 13+.", style = MaterialTheme.typography.bodySmall)
        }
        LVCard(title = stringResource(R.string.data)) {
            OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.export_backup)) }
            Text("Save a portable JSON backup to a location you choose.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.import_backup)) }
            Text("Validate and restore a backup from a selected document.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text(stringResource(R.string.reset_progress)) }
        }
        LVCard(title = stringResource(R.string.about)) {
            Text("Learn Vocabulary · Version 0.1.0")
            Text(stringResource(R.string.word_credit))
            Text("Dictionary data license: GPL-3.0. System fonts are used; large font files are not bundled.")
            Text("The app does not request INTERNET permission and does not provide cloud sign-in or sync.")
        }
    }
}

private fun requestReminderPermissions(context: android.content.Context) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        (context as? Activity)?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9311)
    }
    if (Build.VERSION.SDK_INT >= 31) {
        val manager = context.getSystemService(AlarmManager::class.java)
        if (!manager.canScheduleExactAlarms()) {
            runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, enabled: Boolean = true, onChanged: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChanged, enabled = enabled)
    }
}

@Composable
fun HelpScreen() {
    var query by remember { mutableStateOf("") }
    val articles = listOf(
        "Learning slides" to "A slide contains the number of words set in Settings. Tap Learned to save a word, Learn again to review it later in the same slide, or Learn later to remove it from the current slide.",
        "Difficulty levels" to "A word receives an automatic level from its frequency score. You can select a manual level on its learning card. Tap the selected level again to restore automatic classification.",
        "Search" to "The Words tab searches English words by prefix/substring and Bengali meanings by substring. Use Show more to load the next page.",
        "Custom words" to "Use the plus button in Words. Enter an English word and one or more Bengali meanings separated by commas. Duplicates are rejected.",
        "Quiz" to "The current quiz prototype uses multiple-choice English-to-Bengali questions. Correct and incorrect answers update the spaced-repetition box and mistake flag.",
        "Voice and offline voices" to "Speech uses Android TextToSpeech output only. The app chooses installed voices marked as offline. Install an offline voice in Android Text-to-speech settings if none is available.",
        "Backup and restore" to "Export creates a portable JSON file in a location selected by you. Import validates the schema and shows a summary before changing data.",
        "Reminders" to "Learning and quiz reminders use Android alarms and notifications. Exact-alarm permission and battery optimization settings can affect delivery.",
        "Profile and sign-in" to "The profile name is local to this device. Real account authentication and cloud sync are intentionally unavailable because the app is offline-only.",
        "Offline operation" to "The application has no INTERNET permission. The dictionary and help content are stored locally; no remote search or network services are used."
    )
    PageColumn {
        OutlinedTextField(query, { query = it }, label = { Text("Search Help") }, modifier = Modifier.fillMaxWidth())
        val filtered = articles.filter { (title, body) -> query.isBlank() || title.contains(query, true) || body.contains(query, true) }
        filtered.forEach { (title, body) -> LVCard(title) { Text(body) } }
        if (filtered.isEmpty()) Text("No matching topic. Try ‘quiz’, ‘voice’, ‘backup’ or browse all topics by clearing the search.")
    }
}

@Composable
fun ProfileScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    var name by remember(settings.displayName) { mutableStateOf(settings.displayName) }
    PageColumn {
        LVCard(title = stringResource(R.string.profile)) {
            Text(stringResource(R.string.offline_profile_note))
            OutlinedTextField(name, { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { scope.launch { container.settings.update { it.copy(displayName = name) } } }) { Text(stringResource(R.string.save)) }
        }
    }
}
