package com.learnvocabulary.app

import android.content.Context
import androidx.room.Room
import com.learnvocabulary.app.data.AppDatabase
import com.learnvocabulary.app.data.DictionaryImporter
import com.learnvocabulary.app.data.SettingsRepository
import com.learnvocabulary.app.data.VocabularyRepository
import com.learnvocabulary.app.platform.OfflineSpeechManager

class AppContainer(context: Context) {
    val database: AppDatabase = Room.databaseBuilder(context, AppDatabase::class.java, "learn-vocabulary.db")
        .build()
    val settings = SettingsRepository(context)
    val importer = DictionaryImporter(context, database, settings)
    val vocabulary = VocabularyRepository(database)
    val speech = OfflineSpeechManager(context.applicationContext)
}
