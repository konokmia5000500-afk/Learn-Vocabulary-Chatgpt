package com.learnvocabulary.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.time.LocalDate

class VocabularyRepository(private val database: AppDatabase) {
    private val dao = database.vocabularyDao()
    fun wordCount(): Flow<Int> = dao.observeWordCount()
    fun learningSession(): Flow<LearningSessionEntity?> = dao.observeLearningSession()
    fun dailyStats(): Flow<List<DailyStatEntity>> = dao.observeDailyStats()

    suspend fun startSlide(goal: Int): LearningSessionEntity = withContext(Dispatchers.IO) {
        val selected = dao.nextLearningWords(goal).distinctBy { it.id }
        val session = LearningSessionEntity(
            queueIds = selected.joinToString(",") { it.id.toString() },
            position = 0,
            done = 0,
            initialTotal = selected.size,
            deferredIds = "",
            finished = selected.isEmpty()
        )
        dao.saveLearningSession(session)
        session
    }

    suspend fun currentSlideWord(session: LearningSessionEntity): WordEntity? {
        val ids = parseIds(session.queueIds)
        val id = ids.getOrNull(session.position) ?: return null
        return dao.getWord(id)
    }

    suspend fun markCurrentLearned(session: LearningSessionEntity): LearningSessionEntity {
        val ids = parseIds(session.queueIds)
        val id = ids.getOrNull(session.position) ?: return session.copy(finished = true).also { dao.saveLearningSession(it) }
        database.withTransaction {
            val word = dao.getWord(id)
            dao.markLearned(id)
            if (word != null) {
                val today = LocalDate.now().toString()
                val stat = dao.getDailyStat(today) ?: DailyStatEntity(today)
                val updated = when (word.level()) {
                    "EASY" -> stat.copy(learned = stat.learned + 1, easy = stat.easy + 1)
                    "MEDIUM" -> stat.copy(learned = stat.learned + 1, medium = stat.medium + 1)
                    "HARD" -> stat.copy(learned = stat.learned + 1, hard = stat.hard + 1)
                    else -> stat.copy(learned = stat.learned + 1, veryHard = stat.veryHard + 1)
                }
                dao.putDailyStat(updated)
            }
        }
        val nextPosition = session.position + 1
        return session.copy(position = nextPosition, done = session.done + 1, finished = nextPosition >= ids.size).also { dao.saveLearningSession(it) }
    }

    suspend fun deferCurrent(session: LearningSessionEntity): LearningSessionEntity {
        val ids = parseIds(session.queueIds).toMutableList()
        val current = ids.getOrNull(session.position) ?: return session.copy(finished = true).also { dao.saveLearningSession(it) }
        dao.setLearnAgain(current)
        val deferred = session.deferredIds.split(',').filter(String::isNotBlank).toMutableSet()
        ids.removeAt(session.position)
        if (current.toString() !in deferred) {
            deferred += current.toString()
            val insertion = (session.position + 3).coerceAtMost(ids.size)
            ids.add(insertion, current)
        }
        val finished = session.position >= ids.size
        return session.copy(
            queueIds = ids.joinToString(","),
            deferredIds = deferred.joinToString(","),
            finished = finished
        ).also { dao.saveLearningSession(it) }
    }

    suspend fun skipForLater(session: LearningSessionEntity): LearningSessionEntity {
        val ids = parseIds(session.queueIds).toMutableList()
        val current = ids.getOrNull(session.position) ?: return session.copy(finished = true).also { dao.saveLearningSession(it) }
        dao.setLearnLater(current, true)
        ids.removeAt(session.position)
        val finished = session.position >= ids.size
        return session.copy(queueIds = ids.joinToString(","), initialTotal = ids.size, finished = finished).also { dao.saveLearningSession(it) }
    }

    suspend fun setLevel(id: Long, level: String?) {
        val word = dao.getWord(id) ?: return
        dao.updateWord(word.copy(levelOverride = level))
    }

    suspend fun setLearnLater(id: Long, enabled: Boolean) = dao.setLearnLater(id, enabled)

    suspend fun addCustomWord(word: String, meanings: List<String>, example: String): Boolean {
        val clean = word.trim().lowercase()
        if (!clean.matches(Regex("[a-z]+")) || meanings.none { it.isNotBlank() } || dao.findWord(clean) != null) return false
        return dao.insertWord(
            WordEntity(
                word = clean,
                meanings = meanings.map(String::trim).filter(String::isNotBlank).take(3).joinToString("\u001f"),
                example = example.trim(),
                frequency = 3.8,
                isCustom = true,
                levelOverride = "MEDIUM"
            )
        ) != -1L
    }

    suspend fun deleteCustom(id: Long) = dao.deleteCustomWord(id)
    suspend fun search(query: String, bengali: Boolean, filter: String, customOnly: Boolean, limit: Int, offset: Int) =
        dao.search(query, "$query%", "%$query%", if (bengali) 1 else 0, filter, if (customOnly) 1 else 0, limit, offset)

    suspend fun byId(id: Long) = dao.getWord(id)
    suspend fun allWords() = dao.allWords()
    suspend fun counts() = dao.wordCount() to dao.learnedCount()
    suspend fun stats() = dao.allDailyStats()
    suspend fun levelProgress() = dao.levelProgress()
    suspend fun customWords() = dao.customWords()
    suspend fun recordQuiz(id: Long, correct: Boolean) {
        database.withTransaction {
            val word = dao.getWord(id) ?: return@withTransaction
            val newBox = if (correct) (word.box + 1).coerceAtMost(5) else 0
            val wrong = word.wrongCount + if (correct) 0 else 1
            val right = word.correctCount + if (correct) 1 else 0
            dao.updateQuizResult(id, !correct, newBox, wrong, right, correct)
            val today = LocalDate.now().toString()
            val stat = dao.getDailyStat(today) ?: DailyStatEntity(today)
            dao.putDailyStat(if (correct) stat.copy(quizCorrect = stat.quizCorrect + 1) else stat.copy(quizWrong = stat.quizWrong + 1))
        }
    }
    suspend fun resetAllProgress() {
        database.withTransaction {
            dao.clearDictionaryProgress()
            dao.deleteAllCustomWords()
            dao.clearDailyStats()
            dao.clearLearningSession()
        }
    }

    private fun parseIds(value: String): List<Long> = value.split(',').mapNotNull { it.toLongOrNull() }
}
