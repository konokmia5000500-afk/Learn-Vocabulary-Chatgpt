package com.learnvocabulary.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "words",
    indices = [
        Index(value = ["dictionaryIndex"], unique = true),
        Index(value = ["word"]),
        Index(value = ["isCustom"]),
        Index(value = ["learned"]),
        Index(value = ["learnAgain"]),
        Index(value = ["learnLater"]),
        Index(value = ["mistake"])
    ]
)
data class WordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dictionaryIndex: Int? = null,
    val word: String,
    /** Meanings are separated by U+001F to avoid retaining a parsed JSON tree. */
    val meanings: String,
    val example: String = "",
    val frequency: Double = 0.0,
    val isCustom: Boolean = false,
    val learned: Boolean = false,
    val learnAgain: Boolean = false,
    val learnLater: Boolean = false,
    val mistake: Boolean = false,
    val levelOverride: String? = null,
    val box: Int = 0,
    val wrongCount: Int = 0,
    val correctCount: Int = 0,
    val lastQuizCorrect: Boolean? = null
) {
    fun meaningList(): List<String> = meanings.split('\u001f').map(String::trim).filter(String::isNotEmpty)
    fun level(): String = levelOverride ?: when {
        frequency >= 4.6 -> "EASY"
        frequency >= 3.6 -> "MEDIUM"
        frequency >= 3.0 -> "HARD"
        else -> "VERY_HARD"
    }
}

@Entity(tableName = "daily_stats")
data class DailyStatEntity(
    @PrimaryKey val date: String,
    val learned: Int = 0,
    val easy: Int = 0,
    val medium: Int = 0,
    val hard: Int = 0,
    val veryHard: Int = 0,
    val quizCorrect: Int = 0,
    val quizWrong: Int = 0
)

@Entity(tableName = "learning_session")
data class LearningSessionEntity(
    @PrimaryKey val singletonId: Int = 1,
    val queueIds: String = "",
    val position: Int = 0,
    val done: Int = 0,
    val initialTotal: Int = 0,
    val deferredIds: String = "",
    val finished: Boolean = true
)


data class LevelProgress(
    val level: String,
    val total: Int,
    val learned: Int
)
