package com.learnvocabulary.app.domain

import com.learnvocabulary.app.data.WordEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizEngineTest {
    @Test fun weightedSampleNeverDuplicatesPrimaryWord() {
        val words = (1L..10L).map { WordEntity(id = it, word = "word$it", meanings = "অর্থ", frequency = 3.5) }
        val sample = QuizEngine.weightedSample(words, 8)
        assertEquals(8, sample.size)
        assertEquals(8, sample.map { it.id }.distinct().size)
    }

    @Test fun spacedRepetitionBoxIsBounded() {
        assertEquals(5, QuizEngine.applyCorrectBox(5))
        assertEquals(0, QuizEngine.applyWrongBox())
        assertTrue(QuizEngine.weight(WordEntity(word = "test", meanings = "অর্থ")) > 0.0)
    }
}
