# Complete project file tree

```text
LearnVocabulary/
├── .github/workflows/android.yml
├── NOTICE-DICTIONARY.md
├── README.md
├── app/build.gradle.kts
├── app/proguard-rules.pro
├── app/schemas/README.md
├── app/src/main/AndroidManifest.xml
├── app/src/main/assets/README.txt
├── app/src/main/java/com/learnvocabulary/app/AppContainer.kt
├── app/src/main/java/com/learnvocabulary/app/MainActivity.kt
├── app/src/main/java/com/learnvocabulary/app/VocabApplication.kt
├── app/src/main/java/com/learnvocabulary/app/backup/BackupManager.kt
├── app/src/main/java/com/learnvocabulary/app/data/AppDatabase.kt
├── app/src/main/java/com/learnvocabulary/app/data/DictionaryImporter.kt
├── app/src/main/java/com/learnvocabulary/app/data/Entities.kt
├── app/src/main/java/com/learnvocabulary/app/data/SettingsRepository.kt
├── app/src/main/java/com/learnvocabulary/app/data/VocabularyDao.kt
├── app/src/main/java/com/learnvocabulary/app/data/VocabularyRepository.kt
├── app/src/main/java/com/learnvocabulary/app/domain/QuizEngine.kt
├── app/src/main/java/com/learnvocabulary/app/platform/OfflineSpeechManager.kt
├── app/src/main/java/com/learnvocabulary/app/platform/ReminderReceiver.kt
├── app/src/main/java/com/learnvocabulary/app/platform/ReminderScheduler.kt
├── app/src/main/java/com/learnvocabulary/app/ui/AppScreens.kt
├── app/src/main/java/com/learnvocabulary/app/ui/Theme.kt
├── app/src/main/java/com/learnvocabulary/app/ui/VocabularyRoot.kt
├── app/src/main/res/drawable/ic_lv_logo.xml
├── app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
├── app/src/main/res/mipmap-hdpi/ic_launcher.png
├── app/src/main/res/mipmap-mdpi/ic_launcher.png
├── app/src/main/res/mipmap-xhdpi/ic_launcher.png
├── app/src/main/res/mipmap-xxhdpi/ic_launcher.png
├── app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
├── app/src/main/res/values/colors.xml
├── app/src/main/res/values/strings.xml
├── app/src/main/res/values/styles.xml
├── app/src/main/res/values-bn/strings.xml
├── app/src/main/res/xml/locales_config.xml
├── app/src/test/java/com/learnvocabulary/app/domain/QuizEngineTest.kt
├── build.gradle.kts
├── gradle/libs.versions.toml
├── gradle/wrapper/gradle-wrapper.properties
├── gradle.properties
├── gradlew
├── gradlew.bat
├── settings.gradle.kts
```

Total files shown: **45** (this tree excludes this document and `VERIFICATION.md`).
