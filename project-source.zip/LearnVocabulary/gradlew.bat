@echo off
setlocal
set VERSION=9.5.0
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle --version | findstr /R /C:"Gradle %VERSION%" >nul
  if %ERRORLEVEL% EQU 0 (
    gradle -p "%~dp0" %*
    exit /b %ERRORLEVEL%
  )
)
set GH=%USERPROFILE%\.gradle\wrapper\manual
set DIST=%GH%\gradle-%VERSION%
if not exist "%DIST%in\gradle.bat" (
  if not exist "%GH%" mkdir "%GH%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%GH%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%GH%\gradle-%VERSION%-bin.zip' '%GH%'"
)
call "%DIST%in\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
