# Verification and requirement traceability

**Project:** Learn Vocabulary 0.1.0  
**Package:** `com.learnvocabulary.app`  
**Review date:** 2026-11-26

## Verification environment and evidence

| Check | Result | Evidence / limitation |
|---|---|---|
| Kotlin syntax-level parse | Partial pass | Ran `kotlinc` against all app Kotlin source files. No parser diagnostics such as `expecting`, `unexpected tokens`, or `syntax error` were emitted. The command still exited non-zero because Android, AndroidX, Room, Compose, and coroutine dependencies are not available to standalone `kotlinc` (813 unresolved-reference diagnostics in the captured output). This is not an Android compile. |
| XML well-formedness | Pass | Parsed all 8 XML files under `app/src/main/` with Python `xml.etree.ElementTree`; no malformed XML was found. |
| Workflow copy consistency | Pass | Standalone `android.yml` and `.github/workflows/android.yml` are byte-identical at packaging time. |
| Manifest offline permission check | Pass | `AndroidManifest.xml` does not declare `android.permission.INTERNET`. |
| Gradle build / unit tests / lint | Not verifiable here | Android SDK and Gradle are unavailable, the official wrapper JAR is absent, and outbound network access is disabled. GitHub Actions is provided as the reproducible build route. |
| APK output size | Not measured | No APK could be produced in this environment. Any size estimate would be speculative; measure the Actions artifact after a successful CI build. |
| Physical-device behavior | Not tested | The manual test plan below is required on a real Android device. |

### Commands that were run

```bash
sh -n gradlew
cmp -s ../android.yml .github/workflows/android.yml
kotlinc $(find app/src/main/java -name '*.kt') -d /tmp/lv-check.jar
```

The first command completed successfully. The second confirmed identical workflow files. The third reached the Kotlin compiler but could not resolve the Android/AndroidX dependency graph; it is only useful as a Kotlin parser-level check, not evidence of a successful compilation.

## Requirement traceability

Status meanings: **Implemented** = a concrete implementation exists in this source snapshot; **Partially implemented** = some behavior exists but the full prompt is not satisfied; **Not implemented** = no implementation is supplied; **Not verifiable** = requires Android SDK, CI, device, or supplied data.

| Prompt area | Status | Main implementation | Gaps / notes |
|---|---|---|---|
| Delivery archive, README, workflow | Partially implemented | `README.md`, `FILE_TREE.md`, `.github/workflows/android.yml`, `gradlew`, `gradlew.bat` | ZIP and workflow are provided. A standard Gradle Wrapper JAR is not included; the launcher scripts bootstrap/use Gradle. CI installs Gradle directly. CI result not yet verified. |
| Dictionary structure and import | Partially implemented | `data/DictionaryImporter.kt`, `data/Entities.kt`, `data/VocabularyDao.kt`, `app/src/main/assets/README.txt` | Streaming `JsonReader`, IO dispatcher, batched Room transaction, validation, unknown-field skip, import marker and missing-file retry state exist. Actual `words.json` was not supplied and is not bundled. Duplicate unique dictionary indexes or malformed JSON fail the encompassing transaction; a per-record duplicate recovery policy is not fully implemented. |
| Difficulty classification and override | Implemented | `data/Entities.kt`, `data/VocabularyRepository.kt`, `ui/AppScreens.kt` | Automatic `z` thresholds and manual level override/clear are implemented. |
| Core architecture and persistence | Partially implemented | `AppContainer.kt`, `data/AppDatabase.kt`, `data/VocabularyDao.kt`, `data/SettingsRepository.kt`, `data/VocabularyRepository.kt` | Room, DataStore, IO work, Flow, pagination, and persisted learning slide state exist. Full quiz-session/process-death model, migrations beyond schema v1, and full domain separation are not finished. No destructive migration fallback is present. |
| Six-tab visual navigation | Partially implemented | `ui/VocabularyRoot.kt`, `ui/Theme.kt`, `res/drawable/ic_lv_logo.xml` | Six icon-only destinations and four theme palettes exist. Custom scenery illustrations, polished final logo treatment, full font-style application, and detailed accessibility review are incomplete. |
| Localization | Partially implemented | `res/values/strings.xml`, `res/values-bn/strings.xml`, `data/SettingsRepository.kt`, `MainActivity.kt` | English/Bengali resource sets and immediate locale switching are wired. Several screen/help strings remain hard-coded or English-only; localization completeness is not achieved. |
| Home dashboard and missed-day alerts | Partially implemented | `ui/AppScreens.kt`, `data/VocabularyRepository.kt`, `data/VocabularyDao.kt` | Home cards, navigation shortcuts, and list entry points exist. Full missed-day detection, catch-up markers, quiz reminder card, complete counts/bottom sheets, and alert dismissal logic are not implemented. |
| Learning slides | Partially implemented | `ui/AppScreens.kt`, `data/VocabularyRepository.kt`, `data/Entities.kt` | Persisted queue, start/resume, mark learned, learn-again reinsert behavior, learn-later removal, level selection, word meaning/example and animated transitions exist. Exact goal/catch-up/XP behavior and several edge cases are incomplete. |
| Words search, filters, custom words | Partially implemented | `ui/AppScreens.kt`, `data/VocabularyDao.kt`, `data/VocabularyRepository.kt` | Prefix/contains English and Bengali substring search, LIMIT/OFFSET pages, several filters, custom word add/detail/delete backend exist. UX for delete confirmation, all list sheets and every requested filter combination is incomplete. |
| Quiz setup and game | Partially implemented | `domain/QuizEngine.kt`, `ui/AppScreens.kt`, `data/VocabularyRepository.kt` | Weighted sample without replacement, English-to-Bengali MCQ, five hearts, correctness feedback and spaced-repetition box/wrong flags exist. Other question types, full setup controls, combo bonuses, repeat-wrong queue, match pairs, deterministic cap, persistent quiz session and complete XP accounting are not implemented. |
| Score and history | Partially implemented | `ui/AppScreens.kt`, `data/VocabularyDao.kt`, `data/Entities.kt` | Five progress rings, basic activity bars, quiz totals and day records exist. Streaks, complete 7/30-day calculations, complete history UX, most-missed list, XP/slides/quizzes totals and caught-up history semantics are incomplete. |
| Settings, profile, Help, About | Partially implemented | `ui/AppScreens.kt`, `data/SettingsRepository.kt`, `res/values*/strings.xml` | Local-only profile, appearance options, goal selection, voice controls, reminder controls, Help search and About attribution exist. Help articles are not fully bilingual; some preferences are stored but not applied, and all settings are not fully described/localized. |
| Offline TTS | Partially implemented | `platform/OfflineSpeechManager.kt`, `ui/AppScreens.kt` | TextToSpeech output only; filters voices by `isNetworkConnectionRequired`, supports English accent preference and Bengali availability check. Device voice installation/availability and full lifecycle/auto-speak behavior require device testing. |
| Backup/export/import/reset | Partially implemented | `backup/BackupManager.kt`, `ui/AppScreens.kt` | SAF-based JSON export/import, schema version check and database transaction are implemented. Backup does not yet preserve every requested setting/session/XP/missed-day/caught-up field; import is not a full schema/field parity implementation. Reset keeps dictionary and core appearance/language preferences. |
| Alarms and notifications | Partially implemented | `platform/ReminderScheduler.kt`, `platform/ReminderReceiver.kt`, `MainActivity.kt`, `AndroidManifest.xml` | Exact-alarm/inexact fallback paths, permission helpers, notification channels, receiver and reboot/time rescheduling primitives exist. Exact behavior, duplicate suppression, deep-link handling, and OS-specific delivery are not device-verified; alarm permission-change rescheduling is incomplete. |
| Motion/accessibility/performance | Partially implemented | `ui/AppScreens.kt`, `ui/VocabularyRoot.kt`, `data/VocabularyDao.kt` | Learn and quiz content transitions and paginated query are present. Full navigation transitions, reduced-motion response, list/recomposition profiling, all stable keys and accessibility audit are not complete. |
| Second-pass quality gate | Not verifiable | This report and the unit test source | CI compilation, unit-test execution, Android lint, Room KSP output, release APK, APK size, and all behavioral tests require the configured GitHub runner and a device. |

## Known important limitations before treating this as complete

1. Place the real, correctly licensed `words.json` file at `app/src/main/assets/words.json`. It is intentionally omitted because it was not attached to the request.
2. The feature implementation is a substantial starter implementation but does **not** meet every item in the long specification. The table above names the principal omissions; it must not be represented as production-complete.
3. `app/src/test/java/.../QuizEngineTest.kt` contains unit tests, but those tests have not been run.
4. The CI workflow currently requests Android SDK Platform 37 Extension 1 and Build Tools 37.0.0. If Google's SDK repository changes package availability, adjust the workflow and `compileSdk` together based on the SDK packages available to the runner.
5. Release APKs use the debug signing configuration for personal testing. This is not a release keystore or Play Store signing configuration.
6. No APK size is claimed. The final artifact's actual size must be measured after CI succeeds.

## 25-step manual Android test plan

1. Build and install the debug APK on an Android 7.0+ device; confirm the launcher icon and first launch.
2. Launch without `words.json`; confirm a clear missing-dictionary message and retry action rather than a crash.
3. Add the licensed `words.json`, rebuild/install, and confirm first-run import progress reaches completion.
4. Force-stop and relaunch; verify the dictionary is not imported a second time.
5. Switch English → বাংলা → English while on different screens; verify visible labels update without restarting.
6. Change System, Light, Dark, Sepia and Forest themes and inspect text contrast.
7. Change text size across the supported range and inspect English and Bengali clipping.
8. Change words-per-day and confirm the learning slide uses the selected word count.
9. Navigate through all six bottom icons and confirm each has a meaningful accessibility description.
10. Start a new slide, close the app, relaunch, and confirm the active slide position is restored.
11. Mark a word Learned; confirm it advances and does not reappear in ordinary learning selection.
12. Mark a word Learn again; confirm it returns later in the same slide without increasing learned count.
13. Defer a word repeatedly; confirm no infinite loop or repeated-card lock occurs.
14. Mark a word Learn later; confirm it leaves the slide and appears in the Learn later filter.
15. Change a word's level manually, tap the selected level again, and confirm automatic level is restored.
16. Search English by prefix and interior substring; use Show more and verify pagination does not duplicate rows.
17. Search Bengali meanings and combine search with a level/learn-state filter.
18. Add a custom word, try invalid English and empty Bengali meanings, then confirm validation; delete a custom word and verify it is gone.
19. Open word details and tap the speaker on multiple screens; verify only the intended English word is spoken.
20. Disable network access and test English TTS; verify network-required voices are not selected and missing voice data opens the system install flow.
21. Open quiz using dictionary words; answer correctly and incorrectly; verify heart count, feedback, daily quiz stats and spaced-repetition box/mistake flag.
22. Open quiz with very small word pools and with only custom words; verify graceful insufficient-pool handling and no dictionary words are mixed into My words.
23. Inspect Score rings, daily bars, totals and history after a set of learning and quiz actions; compare values with actual actions.
24. Enable notifications, configure learning and quiz reminders, test normal alarm delivery, reboot/time-change rescheduling, denied notification permission and exact-alarm fallback.
25. Export a backup to a user-selected file, import it on a fresh install, confirm the summary/restore, test a malformed file, reset progress while preserving language, search Help, inspect the local-profile limitation, and finally exercise both GitHub Actions ZIP and conventional repository workflows. Observe Learn/Quiz transitions on a modest device.

## Android Studio build/run checklist

1. Install Android Studio with JDK 17 configured and the Android SDK Platform 37 Extension 1 / Build Tools 37.0.0 packages available.
2. Open the `LearnVocabulary/` directory (the directory containing `settings.gradle.kts`).
3. Add the licensed `words.json` to `app/src/main/assets/words.json`.
4. Allow Gradle sync, then run `:app:assembleDebug` and the `app` configuration on a device/emulator.
5. Run `:app:testDebugUnitTest`; inspect KSP-generated Room schema under `app/schemas/` after a successful build.
6. For a release test build, run `:app:assembleRelease`; remember this build uses debug signing until a real release keystore is configured.

## GitHub Actions and artifact retrieval

**ZIP workflow:** put the delivered project archive in the repository root named exactly `project-source.zip`, put the standalone workflow at `.github/workflows/android.yml`, and (when available) put the licensed dictionary as `words.json` in the repository root. The runner extracts the ZIP, locates `settings.gradle.kts`, copies the root `words.json` to `app/src/main/assets/words.json`, installs the SDK and runs the build. Alternatively, the dictionary may already be inside the ZIP at that asset path. GitHub does not build compressed source without a workflow step to extract it.

**Conventional workflow:** extract the project and commit the contents so `settings.gradle.kts`, `app/`, `gradle/`, and `.github/workflows/android.yml` are at the repository root. Push or dispatch the workflow.

After a successful Actions run: open the repository's **Actions** tab → **Build Learn Vocabulary Android APK** → latest successful run → **Artifacts** → download `LearnVocabulary-release-apk`. Extract the downloaded artifact ZIP on Android and install `app-release.apk`. The artifact is for personal testing and debug-signed.
