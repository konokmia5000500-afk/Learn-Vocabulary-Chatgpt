# Learn Vocabulary — Native Android

**Kotlin · Jetpack Compose · Material 3 · Room · DataStore · Offline-first**

Application ID: `com.learnvocabulary.app`  
Version: `0.1.0`  
Minimum Android: API 24  
Target SDK: API 36  
Compile SDK: API 37.1 (extension level 1)

## What is included

This is a native single-Activity Android Studio project. It contains a Compose six-tab UI, local Room storage, DataStore preferences, streaming JSON dictionary import, English/Bengali search with pagination, custom-word creation, persisted learning slide queue, difficulty overrides, an MCQ quiz prototype, basic score/history screens, local profile, local Help articles, offline-only TextToSpeech voice selection, SAF backup export/import, reminder alarm primitives, and a GitHub Actions release build workflow.

The build has **not** been run in this workspace: no Android SDK, Gradle installation, or outbound network access was available. See `VERIFICATION.md` for exact limitations and the feature-by-feature status. This is an initial engineering implementation, not a claim that every item in the full specification has been finished or device-tested.

## Dictionary data placement

The app expects the dictionary array at:

```text
app/src/main/assets/words.json
```

The expected record shape is:

```json
{"i":300,"w":"often","b":["প্রায়ই","প্রায়শ","বারবার"],"e":"the causes of accidents are often complex","z":5.41}
```

The import parser reads one JSON object at a time and writes batches of 200 records inside a Room transaction. Invalid individual records are skipped; malformed JSON causes the transaction to roll back. A successful import is marked in DataStore so the asset is not parsed again on future launches. If the file is missing, the app shows an error with a retry action.

The original dictionary dataset has not been bundled. Required attribution is recorded in `NOTICE-DICTIONARY.md` and in the app's About section: **“Word data: BengaliDictionary by Minhas Kamal (GPL-3.0)”**. Carry over the original dataset's exact license and copyright notices when adding the file. The app source code is not automatically GPL-3.0; its source license remains unselected.

## Offline and privacy behavior

- The manifest intentionally has no `INTERNET` permission.
- There are no remote APIs, analytics, ads, or cloud sync.
- The profile is a local display name only, not a real online account.
- Speech uses Android TextToSpeech output only and selects voices marked as not requiring network synthesis. Availability depends on installed Android voice data.
- Notification and exact-alarm permissions are separate Android system controls; reminder delivery is not guaranteed when the OS delays alarms or notifications are denied.

## Build requirements and commands

Use an Android Studio version with support for AGP 9.3.1 and install Android SDK Platform 37 Extension 1 / Build Tools 37.0.0. JDK 17 is used by CI.

From the project root:

```bash
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleRelease
```

`gradlew` and `gradlew.bat` are included as small bootstrap launchers. The official Gradle Wrapper JAR is not included because it could not be downloaded in the isolated creation environment; the scripts use an installed Gradle 9.5.0 when available or download the Gradle 9.5.0 distribution on first use. The CI workflow installs Gradle directly with `gradle/actions/setup-gradle` and does not depend on a wrapper JAR.

Room schema export is enabled. The first successful KSP build generates the version-1 Room schema JSON under `app/schemas/`. Future database changes must increment `AppDatabase.version` and add an explicit migration. Destructive migration fallback is not enabled.

## Release signing

The current release build is signed with the Android debug signing configuration so the CI APK can be installed for personal testing. **This is not a production signing setup.** Before publishing, configure a release keystore in GitHub Secrets or locally and replace the debug signing configuration. No keystore or credentials are included in this project.

## GitHub Actions: two supported layouts

### A. Phone-only ZIP workflow

1. Create a GitHub repository.
2. Upload `project-source.zip` to the repository root. It should be the ZIP downloaded from this delivery.
3. Upload the separate `android.yml` file to exactly `.github/workflows/android.yml`.
4. Upload the licensed dictionary as `words.json` in the repository root (optional but required for a populated first launch). The workflow automatically copies this root file to `app/src/main/assets/words.json` after extracting the project. Alternatively, include `words.json` inside the project ZIP at that asset path.
5. Commit the ZIP, workflow, and (when available) dictionary to `main` (or `master`).
6. Push the commit. The Actions workflow reads `project-source.zip`, extracts it inside the runner, finds `settings.gradle.kts`, installs Android SDK packages, runs tests/build, and uploads the APK. GitHub Actions does not execute source code while it remains compressed; extraction happens automatically inside the runner.

Simply uploading a ZIP to a random GitHub page does not trigger a build. The ZIP and workflow must be committed to the same repository at the documented paths, and a push, pull request, or manual workflow dispatch must start a run.

### B. Conventional extracted project repository

1. Extract the project ZIP on a computer or using an archive app.
2. Upload the contents of the `LearnVocabulary/` project folder to the repository root, preserving `settings.gradle.kts`, `app/`, `gradle/`, `gradlew`, and `.github/` paths.
3. Ensure `.github/workflows/android.yml` is present.
4. Commit and push. The workflow detects the root `settings.gradle.kts` and builds without expecting a `project-source.zip`.

The standalone `android.yml` delivered with the project is copied byte-for-byte to `.github/workflows/android.yml` inside the project ZIP. Keep them synchronized when editing the workflow. A repository-root `words.json`, when present, is copied into the extracted project before Gradle runs.

## Downloading the APK on Android

Open the repository on GitHub → **Actions** → choose **Build Learn Vocabulary Android APK** → open the latest successful run → scroll to **Artifacts** → download **LearnVocabulary-release-apk**. GitHub downloads an artifact ZIP. Extract it on the phone and install the `app-release.apk` file. Allow installation from the browser/file manager when Android requests it. The APK is debug-signed for testing; it is not a Play Store production build.

## File map

See `FILE_TREE.md` for the complete project tree and `VERIFICATION.md` for the traceability checklist and a 25-step phone test plan.
