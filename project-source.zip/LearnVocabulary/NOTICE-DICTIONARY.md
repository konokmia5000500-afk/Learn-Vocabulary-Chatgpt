# Dictionary data attribution and license notice

The application is designed to use the `words.json` dictionary data supplied by the project owner.

Required attribution from the project specification:

> Word data: BengaliDictionary by Minhas Kamal (GPL-3.0)

The dictionary data file is **not included** in this archive because it was not supplied with the request. When adding the original data file, preserve the license and copyright notices distributed with that exact dataset, and include the GPL-3.0 license text applicable to the dataset. This notice does not place the Android application source code under GPL-3.0. The application source license has not been selected in this project.
